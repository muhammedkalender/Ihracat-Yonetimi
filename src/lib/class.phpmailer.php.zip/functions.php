<?php
require 'class.phpmailer.php';
include "functions.runtime.php";
// GENEL Tanımlamalar

function degisimsart()
{
	
	$dds=mysql_query("select * from M_Firma");
	$i=0;
	while(mysql_fetch_array($dds))
	{
		$id=$dds["id"];
		$FirmaAdi=$dds["FirmaAdi"];
		$Adres=$dds["Adres"];
		$Il=$dds["Il"];
		$Ulke=$dds["Ulke"];
		$Sektor1=$dds["Sektor1"];
		$Sektor2=$dds["Sektor2"];
		$Sektor3=$dds["Sektor3"];

		if(mysql_query("update M_Firma SET FirmaAdi='$FirmaAdi', Adres='$Adres', Il='$Il', Ulke='$Ulke', Sektor1='$Sektor1', Sektor2='$Sektor2', Sektor3='$Sektor3',  WHERE FirmaKod='$id'"))
		{
			echo "<script>alert('1')</script>";
		}

	
	}
	
$healthy = array("ý", "ð", "ü", "þ", "ö", "ç", "Ð", "Ü", "Þ", "Ý", "Ö", "Ç");
$yummy   = array("Ä±", "ÄŸ", "Ã¼", "ÅŸ", "Ã¶", "Ã§", "Äž", "Ãœ", "Åž", "Ä°", "Ã–", "Ã‡");

$newphrase = str_replace($healthy, $yummy, $phrase);

return $newphrase;
}
function GirisYapmisMi() {
	global $session;
	if ($session->logged_in) {
		return true;
	}else{
		header("Location: /login?".URL::encode("?git=".base64_decode(Adres()).""));
		exit();
	}
}
function getRealIpAddr()  
{  
    if (!empty($_SERVER['HTTP_CLIENT_IP']))  
    {  
        $ip=$_SERVER['HTTP_CLIENT_IP'];  
    }  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) //Proxy den bağlanıyorsa gerçek IP yi alır.
     
    {  
        $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];  
    }  
    else  
    {  
        $ip=$_SERVER['REMOTE_ADDR'];  
    }  
    return $ip;  
}  
function LogTut($yazi)
{
global $session;

	$kullan=$session->username;
	

if (!empty($_SERVER['HTTP_CLIENT_IP']))  
    {  
        $ip=$_SERVER['HTTP_CLIENT_IP'];  
    }  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) //Proxy den bağlanıyorsa gerçek IP yi alır.
     
    {  
        $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];  
    }  
    else  
    {  
        $ip=$_SERVER['REMOTE_ADDR'];  
    }  


	if(mysql_query("insert into Log_ set log = '$yazi',kullanici='$kullan', zaman = '".time()."', ip = '$ip'"))
	{
	
	}
}


function GirisYapan() {
	global $session;
	if ($session->logged_in) {
		$q = mysql_query("select * from users where username = '".$session->username."'");
		$a = mysql_fetch_array($q);
		return array(
			'email' => $a["email"],
			'adi' => $a["adi"],
			'soyadi' => $a["soyadi"],
			'unvan' => $a["unvan"],
			'gorev' => $a["gorev"],
			'amir' => $a["amir"],
			'cinsiyet' => $a["cinsiyet"],
			'dogumtarihi' => $a["dogumtarihi"],
			'fotograf' => $a["fotograf"],
			'alan' => $a["alan"]
		);
	}
}
function toplantiilgiogren($id)
{
	global $session;
	
	$kullanici=$session->username;
	
	$dc=mysql_query("select id from toplantiKayit WHERE id='$id' AND (baskan LIKE '%$kullanici%' OR raportor LIKE '%$kullanici%' OR sahip LIKE '%$kullanici%')");
	
	if(mysql_num_rows($dc)>0)
	{
	return 1;
	}
	else
	{
		$dc=mysql_query("select id from toplantiKayit WHERE id='$id' AND (katilimci LIKE '%$kullanici%') ");
			if(mysql_num_rows($dc)>0)
			{	
				return 2;	
			}
			else
			{
				return 0;
			}

	
	}
}
function AdminAlani() {
	global $session;
	if ($session->userlevel < 5) {
		header("Location: /login");
		exit();
	}
}
function ZorunluAlan($mesaj=false) {
	if ($mesaj !== false) {
		$mesaj = $mesaj;
	}else{
		$mesaj = "Lütfen bu alanı doldurunuz";
	}
	return "{validate:{required:true, messages:{required:'".$mesaj."'}}}";
}
function PhpSelf() {
	return $_SERVER["PHP_SELF"];
}
function Adres() {
	$pageURL = 'http';
	if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
	$pageURL .= "://";
	if ($_SERVER["SERVER_PORT"] != "80") {
	$pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
	} else {
	$pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
	}
	return base64_encode($pageURL);
}
function SubmitButton($str,$renk="",$disabled="") {
	if ($renk == "yesil") {
		$class = " green";
	}elseif ($renk == "mavi") {
		$class = " blue";
	}elseif ($renk == "turuncu") {
		$class = " orange";
	}elseif ($renk == "kirmizi") {
		$class = " red";
	}else{
		$class = "";
	}
	return '<button type="submit" id="submit" class="loading '.$class.'"'.$disabled.'><span>'.$str.'</span></button>';
}
function SubmitButtonS($str,$renk="",$disabled="") {
	if ($renk == "yesil") {
		$class = " green";
	}elseif ($renk == "mavi") {
		$class = " blue";
	}elseif ($renk == "turuncu") {
		$class = " orange";
	}elseif ($renk == "kirmizi") {
		$class = " red";
	}else{
		$class = "";
	}
	return '<button width="25" Height="25" type="submit" id="submit"'.$disabled.'><span>'.$str.'</span></button>';
}

function SolTarafGuncelle($te)
{
	$idpo=2;
	$te .=" ";
if(mysql_query("update incsol SET yazi='$te' WHERE id='$idpo'"))
	{
echo "<script type='text/javascript'> alert('Başarılı'); </script>";
}else
	{


echo "<script type='text/javascript'> alert('HATA!!'); </script>";
}
}
function DeleteButton($href,$onclick,$class,$id,$width="16") {
	
	return '<a href="'.$href.'" onclick="'.$onclick.'" class="item small loading '.$class.'" '.$id.'><img src="/gfx/icons/small/cancel.png" alt="Cancel" width="'.$width.'" /></a>';
}
function OnayButton($href,$onclick,$class,$id,$width="16") {
	
	return '<a href="'.$href.'" onclick="'.$onclick.'" class="item small loading '.$class.'" '.$id.'><img src="/gfx/icons/small/check.png" alt="Cancel" width="'.$width.'" /></a>';
}
function CheckButton($href,$onclick,$class,$id,$width="16") {
	
//return '<a href="'.$href.'" class="item small"  id="'.$id.'"><img src="/gfx/icons/small/edit.png" alt="Cancel" width="'.$width.'" /></a>';	
	return '<a href="'.$href.'"  class="item small" id="'.$id.'"><img src="/gfx/icons/small/check.png" alt="Cancel" width="'.$width.'" /></a>';
}
function CheckButton2($href,$onclick,$class,$id,$width="16") {
	
//return '<a href="'.$href.'" class="item small"  id="'.$id.'"><img src="/gfx/icons/small/edit.png" alt="Cancel" width="'.$width.'" /></a>';	
	return '<a href="'.$href.'" target="_blank"  class="item small" id="'.$id.'"><img src="/gfx/icons/small/check.png" alt="Cancel" width="'.$width.'" /></a>';
}
function EditButton($href,$onclick,$class,$id,$width="16") {
	
	
	return '<a href="'.$href.'" onclick="'.$onclick.'" class="item small '.$class.'" id="'.$id.'"><img src="/gfx/icons/small/edit.png" alt="Cancel" width="'.$width.'" /></a>';
}
function SearchButton($href,$onclick,$class,$id,$width="16") {
	
	
	return '<a href="'.$href.'" onclick="'.$onclick.'" class="item small '.$class.'" id="'.$id.'"><img src="/gfx/icons/small/search.png" alt="Cancel" width="'.$width.'" /></a>';
}

function Dofibaslatabilecekler()
{
	global $session;
//echo "<script type='text/javascript'> alert('".$session->username."'); </script>";
$s = mysql_query("select * From iyilestirme_DofiKullanici where Kullanici='$session->username'");
if(mysql_num_rows($s)>0)
	{
return 1;
	}
else
	{
	return 0;
	}
}
function adsoyadgorevbul($kullanici)
{
$s = @mysql_query("select adi,soyadi,gorev From users where username='$kullanici'");
$ok=@mysql_fetch_object($s);
$grv=$ok->gorev;
$se = @mysql_query("select adi From gorevler where id='$grv'");
$gorevi=@mysql_fetch_object($se);
$grev=$gorevi->adi;

$strn=$ok->adi." ".$ok->soyadi." (".$grev.")";

return $strn;

}
function dagitimdami($id,$kul)
{
	$kul="-".$kul.",";
	$d=mysql_query("select * from duyuru where id='$id' AND (dagitim LIKE '%".$kul."%' || dagitim = '-99999,')");
	if(@mysql_num_rows($d)>0)
	{
		return "1";
	}else{
		return "0";
	}

}
function okundumu($id,$kul)
{
	$d=mysql_query("select * from duyuru_okudum where did='$id' AND kullanici='".$kul."'");
	if(@mysql_num_rows($d)>0)
	{
		$o=mysql_fetch_array($d);
		return $o["tarihi"];
	}else
	{
		return "0";
	}
}
function adsoyadgorevbul2($kullanici)
{

$s = mysql_query("select adi,soyadi,gorev,username From users");
$strn="";
while($ok=@mysql_fetch_object($s))
	{

if(strstr($kullanici,"-".$ok->username.","))
		{
$grv=$ok->gorev;
$se = mysql_query("select adi From gorevler where id='$grv'");
$gorevi=mysql_fetch_object($se);
$grev=$gorevi->adi;

$strn .=$ok->adi." ".$ok->soyadi." (".$grev.")<br>";
		}
}

return $strn;

}
function adsoyadbul($kullanici){
$s = @mysql_query("select adi,soyadi,gorev From users where username='$kullanici'");
$ok=@mysql_fetch_object($s);


$strn=$ok->adi." ".$ok->soyadi;

return $strn;
}
function adsoyadgorevbulid($id)
{
$s = @mysql_query("select adi,soyadi,gorev From users where gorev='$id'");
$ok=@mysql_fetch_object($s);
$grv=$ok->gorev;
$se = @mysql_query("select adi From gorevler where id='$grv'");
$gorevi=@mysql_fetch_object($se);
$grev=$gorevi->adi;

$strn=$ok->adi." ".$ok->soyadi." (".$grev.")";

return $strn;

}
function toplantiyeribul($id)
{

$s = @mysql_query("select adi From toplantiYerleri where id='$id'");
if(mysql_num_rows($s)>0)
	{
$ok=@mysql_fetch_object($s);
$grv=$ok->adi;
return $grv;
}else
	{
return $id;
}





}
function surecsahibibul($surecadi)
{

	$q = mysql_query("select sahibi from surecler WHERE (id='$surecadi' OR adi = '$surecadi') AND bagli_surec>'0'");
		$a = @mysql_fetch_object($q);
			$SurecIdx=$a->sahibi;

return adsoyadgorevbulid($SurecIdx);
		

}
function surecsahibibul2($surecid)
{

	$q = mysql_query("select sahibi from surecler WHERE id = '$surecid'");
		$a = mysql_fetch_object($q);
			$SurecIdx=$a->sahibi;

return $SurecIdx;
		

}
function degisikliktalebivarmi($id)
{
	$q = mysql_query("select * from performansGostergeleri_hedefler where GostergeId='$id'");

		while($o=@mysql_fetch_array($q))
		{
			$q1= mysql_query("select * from PerformansGostergeleri_veriler where HedefId='".$o["id"]."'");
				if(mysql_num_rows($q1)>0)
				{
					return 1;
				}
		}

return 0;

}
function surecraporgonderilenvarmi($surecid,$kul)
{

	$q = mysql_query("select * from surec_per_rapor_gonder WHERE RaporId = '$surecid' and Gonder='$kul'");
		
			$SurecIdx=@mysql_num_rows($q);

return $SurecIdx;
		

}
function surecsahibimi($username)
{

$wq=mysql_query("select gorev from users where username='$username'");
$a1=mysql_fetch_array($wq);
$gorev=$a1["gorev"];
	$q = mysql_query("select sahibi from surecler WHERE sahibi = '$gorev' AND bagli_surec!='0'");
		
			$SurecIdx=mysql_num_rows($q);

return ($SurecIdx);
		

}
function surecsahibibulkullaniciadi2($surecadi)
{

	$q = mysql_query("select sahibi from surecler WHERE (id='$surecadi' OR adi = '$surecadi') AND bagli_surec!='0'");
		$a = mysql_fetch_object($q);
			$SurecIdx=$a->sahibi;

return ($SurecIdx);
		

}
function sifiratma($veri)
{
$str=explode('.',$veri); 
$veri2=$str[0];
if(strlen($veri2)>5)
				{
return ($veri2/1000000);
}else if(strlen($veri2)>3)
				{
return ($veri2/1000);

}else
	{
return $veri;
}
}
function gorevbul2($surecadi)
{

	$q = mysql_query("select username from users WHERE gorev = '$surecadi'");
		$a = mysql_fetch_object($q);
			$SurecIdx=$a->username;

return ($SurecIdx);
		

}
function gorevbul($surecadi)
{

	$q = mysql_query("select gorev from users WHERE username = '$surecadi'");
		$a = mysql_fetch_object($q);
			$SurecIdx=$a->gorev;

return ($SurecIdx);
		

}
function Toplantifaliyetdurum($surecadi)
{
if($surecadi!="")
	{
	$q = mysql_query("select durum from toplantiFdurum WHERE id = '$surecadi'");
		$a = mysql_fetch_object($q);
			$SurecIdx=$a->durum;

return ($SurecIdx);
	}else
	return ("Durum Yok");	

}
function Toplantidurum($did)
{
if($did!="")
	{
	$q = mysql_query("select durum from toplantiDurum WHERE id = '$did'");
		$a = mysql_fetch_object($q);
			$SurecIdx=$a->durum;

return ($SurecIdx);
	}else
	return ("Durum Yok");	

}
function goruntulemefonk($DofTuru,$DofNeden,$ilgiliSurec,$Uygunsuzluk,$file,$son_id,$KimeGonderilecek,$kullanici,$gonderilen)
{
$s = mysql_query("select adi,soyadi,gorev From users where username='$kullanici'");
$ok=mysql_fetch_array($s);
$grv=$ok["gorev"];
$se = mysql_query("select adi From gorevler where id='$grv'");
$gorevi=mysql_fetch_array($se);
$grev=$gorevi["adi"];

$kimden=$ok["adi"]." ".$ok["soyadi"]." (".$grev.")";

$sp = mysql_query("select sahibi,adi From surecler where id='$ilgiliSurec'");
$oks=mysql_fetch_array($sp);

$ss=adsoyadgorevbulid($oks["sahibi"]);


echo "<div class=\"message green\">
				<span>Kaydınız başarıyla alınmıştır. Teşekkür ederiz.</span>
		</div>";
echo"<div class='content'>";

echo"<table border='0' cellspacing='0' cellpadding='0'>";
echo"<thead><tr><th colspan='3'><i><u>".$son_id."</u></i> NUMARALI DÜZELTİCİ / ÖNLEYİCİ FAALİYET (DÖF) İSTEĞİ</th></tr><thead>";
echo"<tbody>";
//echo "<tr><td width=\"120\"><b>DÖFİ No</b></td><td >  ".$son_id."</td></tr>";
echo "<tr><td width=\"120\"><b>DÖFİ Türü</b></td><td colspan='2'>  ".$DofTuru."</td></tr>";
echo "<tr><td width=\"120\"><b>DÖFİ Nedeni</b></td><td colspan='2'>  ".$DofNeden."</td></tr>";
echo "<tr><td width=\"120\"><b>Kayıt Tarihi</b></td><td colspan='2'>  ".Date('Y.m.d')."</td></tr>";
echo "<tr><td width=\"120\"><b>İlgili Süreç</b></td><td colspan='2'>  ".$oks["adi"]."</td></tr>";
echo "<tr><td width=\"120\"><b>Kimden</b></td><td colspan='2'>  ".$kimden."</td></tr>";
echo "<tr><td width=\"120\"><b>Kime</b></td><td colspan='2'>  ".$ss."</td></tr>";
echo "<tr><td align=\"left\" valign=\"top\" width=\"120\"><b>Uygunsuzluk Tanımı</b></td><td colspan='2'><label>".$Uygunsuzluk."</label></td></tr>";
if($gonderilen=="")
$gonderilen="-";
echo "<tr><td align=\"left\" valign=\"top\" width=\"120\"><b>Bilgilendirilenler</b></td><td colspan='2'>".$gonderilen."</td></tr>";
if($file!="")
echo "<tr><td align=\"left\" valign=\"top\" width=\"120\"><b>Dosya</b></td><td colspan='2'>".'<a href="http://sigma.onlinekalite.com/download.php?'.URL::encode("?d=".str_replace("//","/",$file)."&i=".$son_id."_Nolu_DOF_Eki"."").'">'."Ek Dosya".'</a>'."</td></tr>";



echo "</tbody></table>";
echo "<br>";
echo "<table><tr><td><form action=\"../iyilestirmeDofListesi\">
 ".SubmitButton("DÖF TAKİP LİSTESİNİ AÇ","yesil")."
</form></td>";


echo"</tr></table>";
echo "</div>";
}
function EditButton2($href,$onclick,$class,$id,$width="16") {
	
	
	return '<a href="'.$href.'" class="item small"  id="'.$id.'"><img src="/gfx/icons/small/edit.png" alt="Cancel" width="'.$width.'" /></a>';
}
function EditButton3($href,$onclick,$class,$id,$width="16") {
	
	
	return '<a href="'.$href.'" class="item small"  id="'.$id.'"><img src="/gfx/icons/small/search.png" alt="Cancel" width="'.$width.'" /></a>';
}
function EditButton4($href,$onclick,$class,$id,$width="16") {
	
	
	return '<a href="'.$href.'" class="item small"  id="'.$id.'"><img src="/gfx/icons/small/door.png" alt="Cancel" width="'.$width.'" /></a>';
}
function ReloadButton() {
	return '<span style="padding-left: 20px;"><a href="'.Phpself().'?" class="loading" ><img src="/gfx/icons/small/reload.png" alt="yenile" width="10" class="tip-s" original-title="'.dil_tabloyuyenile_tip.'" /></a></span>';
}

function BreadCrumb($linkler) {
	return '
	<div id="breadcrumbs">
		<ul>
			<li></li>
			<li><a href="/">Anasayfa</a></li>
			'.$linkler.'
		</ul>
	</div>
	';
}
function UsernameAdiSoyadi($u) {
	$q = mysql_query("select adi, soyadi from users where username = '$u'");
	$a = mysql_fetch_object($q);
	return "".$a->adi." ".$a->soyadi."";
}
function UsernameGorev($u) {
	$q = mysql_query("select gorev from users where username = '$u'");
	$a = mysql_fetch_object($q);
	return "".GorevAdiBul($a->gorev)."";
}
function UnvanAdiBul($id) {
	$q = mysql_query("select adi from unvanlar where id = '$id'");
	$a = mysql_fetch_object($q);
	return $a->adi;
}
function UnvanAdiKisiBul($id) {
	$q = mysql_query("select adi, soyadi from users where unvan = '$id'");
	$a = mysql_fetch_object($q);
	return "".$a->adi." ".$a->soyadi."";
}
function GorevAdiBul($id) {
	$q = mysql_query("select adi from gorevler where id = '$id'");
	$a = mysql_fetch_object($q);
	return $a->adi;
}
function GorevAdiKisiBul($id) {
	$q = mysql_query("select adi, soyadi from users where gorev = '$id'");
	$a = mysql_fetch_object($q);
	return "".$a->adi." ".$a->soyadi."";
}
function DokumanYapisiAdiBul($id,$kod=true) {
	$dd = new Database();
	$dd->query("select * from dokumanyapisi where id = '$id'");
	$dd->singleRecord();
		if ($kod) {
			$kodubas = "[".$dd->Record["kod"]."] ";
		}else{
			$kodubas = "";
		}
	return $kodubas.$dd->Record["turu"];
}
function DokumanAdiBul($dokId) {
	$q = mysql_query("select DokumanAdi from dokumanlar where id = '$dokId'");
	$a = mysql_fetch_object($q);
	return $a->DokumanAdi;
}
function AlanAdiBul($id) {
	$q = mysql_query("select Adi from Alan where id = '$id'");
	$a = mysql_fetch_object($q);
	return $a->Adi;
}
function DokumanTalepAdiBul($id) {
	$q = mysql_query("select DokumanAdi from dokumanTalepleri where id = '$id'");
	$a = mysql_fetch_object($q);
	return $a->DokumanAdi;
}
function DokumanRevizyonTalepAdiBul($id) {
	$q = mysql_query("select DokumanAdi from dokumanRevizyonTalepleri where id = '$id'");
	$a = mysql_fetch_object($q);
	return $a->DokumanAdi;
}
function Alan($zorunlu=0,$selected="") {
	global $db;
	$db->query("select * from Alan order by Adi");
	if ($zorunlu == 1) {
		$zorunlu = " ".ZorunluAlan()."";
	}else{
		$zorunlu = "";
	}
	if ($db->numRows() >= 1) {
		$bas = "<select name='Alan' id='Alan' class=\"big".$zorunlu."\"><option value=''>Lütfen alan seçiniz";
		while ($db->nextRecord()) {
			if ($selected == $db->Record["id"]) {
				$selected = " selected";
			}
			$bas .= "<option value='".$db->Record["id"]."'".$selected.">".$db->Record["Adi"]."</option>";
		}
		$bas .= "</select>";
	}
	return $bas;
}



function SurecBul($id) {
	$q = mysql_query("select Adi from surecler where id = '$id'");
	$a = mysql_fetch_object($q);
	return $a->Adi;
}

function EncodeUrl($input)
{
    return strtr(base64_encode($input), '+/=', '-_,');
}

function DecodeUrl($input)
{
    return "&".base64_decode(strtr($input, '-_,', '+/='));
}
function SoruIsareti($str) {
	return "<img src='/gfx/FAQ-icon16px.png' class='tipsari' original-title=\"".$str."\" />";
}
function Tarih($linuxtime,$format="d.m.Y") {
	if ($linuxtime == "0") {
		return "---";
	}else{
		return date($format, $linuxtime);
	}
}
function Unvanlar_Selectbox($selected="",$required=0,$showNames=0) {
	$dt = new Database();
	$dt->query("select * from unvanlar order by adi ASC");
	if ($required == 1) {
		$required = " {validate:{required:true, messages:{required:'Lütfen bir unvan giriniz'}}}";
	}else{
		$required = "";
	}
	$bas = "<select name='unvan' id='unvan' class=\"big ".$required."\">
	<option value=''>Seçiniz</option>
	";
		while ($dt->nextRecord()) {
			if (!empty($selected)) {
				if ($dt->Record["id"] == $selected) {
					$sec = "selected";
				}else{
					$sec = "";
				}
			}
			if ($showNames == 1) {
				$adi = " (".UnvanAdiKisiBul($dt->Record["id"]).")";
			}else{ 
				$adi = "";
			}
			$bas .= "<option value='".$dt->Record["id"]."'".$sec.">".$dt->Record["adi"]."".$adi."</option>";
		}
	$bas .= "</select>";
	return $bas;
}

function Gorevler_Seletbox($selected="",$required=0,$showNames=0,$selectaramali="",$name=false,$multiple=false) {
	if ($required == 1) {
		$required = " {validate:{required:true, messages:{required:'Lütfen bir görev giriniz'}}}";
	}else{
		$required = "";
	}
	$dt = new Database();
	$dt->query("select * from gorevler order by adi ASC");
	if ($name) {
		$selectName = $name;
	}else{
		$selectName = "gorev";
	}
	if ($multiple) {
		$Multiple = " multiple";
		$nameArray = "[]";
	}else{
		$Multiple = "";
		$nameArray = "";
	}
	
	$bas = "<select name='".$selectName."".$nameArray."' id='".$selectName."' class=\"big".$required." ".$selectaramali."\" style='width: 250px;'".$Multiple.">
	<option value=''>Seçiniz</option>
	";
		while ($dt->nextRecord()) {
			if (!empty($selected)) {
				if ($dt->Record["id"] == $selected) {
					$sec = "selected";
				}else{
					$sec = "";
				}
			}
			if ($showNames == 1) {
				$adi = " (".GorevAdiKisiBul($dt->Record["id"]).")";
			}else{ 
				$adi = "";
			}
			$bas .= "<option value='".$dt->Record["id"]."'".$sec.">".$dt->Record["adi"]."".$adi."</option>";
		}
	$bas .= "</select>";
	return $bas;
}
function Gorevler_Seletbox2($selected="",$required=0,$showNames=0,$selectaramali="",$name=false,$multiple=false) {
	if ($required == 1) {
		$required = " {validate:{required:true, messages:{required:'Lütfen bir görev giriniz'}}}";
	}else{
		$required = "";
	}
	$dt = new Database();
	$dt->query("select * from gorevler order by adi ASC");
	if ($name) {
		$selectName = $name;
	}else{
		$selectName = "gorev";
	}
	if ($multiple) {
		$Multiple = " multiple";
		$nameArray = "[]";
	}else{
		$Multiple = "";
		$nameArray = "";
	}
	
	$bas = "<select name='".$selectName."".$nameArray."' id='".$selectName."' class=\"big".$required." ".$selectaramali."\" style='width: 250px;'>
	
	";
		while ($dt->nextRecord()) {
			
			if ($showNames == 1) {
				$adi = " (".GorevAdiKisiBul($dt->Record["id"]).")";
			}else{ 
				$adi = "";
			}
			if (!empty($selected)) {
				if ($dt->Record["id"] == $selected) {
					$bas .= "<option value='".$dt->Record["id"]."' selected>".$dt->Record["adi"]."".$adi."</option>";
				}
			}
			
		}
	$bas .= "</select>";
	return $bas;
}
function Users_Selectbox($name,$selected="",$required=0,$selectaramali=false,$seciniz=false) {
	$dt = new Database();
	$dt->query("select username, gorev, adi, soyadi from users order by adi ASC");
	if ($required == 1) {
		$required = "{validate:{required:true, messages:{required:'Lütfen seçiniz'}}}";
	}else{
		$required = "";
	}
	$bas = "<select name='$name' id='$name' class=\"big $required $selectaramali\" style='width: 350px;'>";
	if ($seciniz) {
		$bas .= "<option value='0'>Seçiniz</option>";
	}
		while ($dt->nextRecord()) {
			if (!empty($selected)) {
				if ($dt->Record["username"] == $selected) {
					$sec = "selected";
				}else{
					$sec = "";
				}
			}
			$bas .= "<option value='".$dt->Record["username"]."'".$sec.">".GorevAdiBul($dt->Record["gorev"])." - ".$dt->Record["adi"]." ".$dt->Record["soyadi"]."</option>";
		}
	$bas .= "</select>";
	return $bas;
}
function Users_Selectbox2($name,$selected="",$required=0,$selectaramali=false,$seciniz=false) {
	$dt = new Database();
	$dt->query("select username, gorev, adi, soyadi from users order by adi ASC");
	if ($required == 1) {
		$required = "{validate:{required:true, messages:{required:'Lütfen seçiniz'}}}";
	}else{
		$required = "";
	}
	$bas = "<select multiple name='$name' id='$name' class=\"big $required $selectaramali\" style='width: 350px;'>";
	if ($seciniz) {
		$bas .= "<option value='0'>Seçiniz</option>";
	}
		while ($dt->nextRecord()) {
			if (!empty($selected)) {
				if ($dt->Record["username"] == $selected) {
					$sec = "selected";
				}else{
					$sec = "";
				}
			}
			$bas .= "<option value='".$dt->Record["username"]."'".$sec.">".GorevAdiBul($dt->Record["gorev"])." - ".$dt->Record["adi"]." ".$dt->Record["soyadi"]."</option>";
		}
	$bas .= "</select>";
	return $bas;
}
function DokumanYapisi_Selectbox_CheckAlt($dbid,$indent, $selected) {
	$q = mysql_query("select * from dokumanyapisi where altId = '$dbid'");
	$t = mysql_num_rows($q);

		if ($t >= 1) {
			$indent = $indent."-";
			while ($a = mysql_fetch_array($q)) {
				$id = $a["id"];
				$adi = $a["turu"];
				if (!empty($selected)) {
					if ($id == $selected) {
						$sec = "selected";
					}else{
						$sec = "";
					}
				}

				$cikti .= "<option value='".$id."'".$sec.">".$indent."> $adi</option>". DokumanYapisi_Selectbox_CheckAlt($id,$indent,$selected);
			
			}
		}else{
			$cikti = "";
		}
	return $cikti;
}
function DokumanYapisi_Selectbox($selected="",$required=0) {
	if ($required == 1) {
		$required = " {validate:{required:true, messages:{required:'Lütfen bir tür giriniz'}}}";
	}else{
		$required = "";
	}
	$k = mysql_query("select * from dokumanyapisi where altId = '0' order by sira ASC");
		while ($a = mysql_fetch_array($k)) {
			$kat_id = $a["id"];
			$kat_name = $a["turu"];

			if (!empty($selected)) {
				if ($kat_id == $selected) {
					$sec = "selected";
				}else{
					$sec = "";
				}
			}

			$bas .= "<option value='".$kat_id."'".$sec.">$kat_name</option>".DokumanYapisi_Selectbox_CheckAlt($kat_id, "-", $selected);
		}
	$basalim = "<select name='dokumanyapisi' class=\"big".$required."\"><option value='0'>Lütfen Seçiniz<option value='0'>Bağlı doküman türü yok</option>";
	$basalim .= $bas;
	$basalim .= "</select>";
	return $basalim;
}

function Dokumanlar_Selectbox($selected="",$required=0,$aramali=0) {
	global $db;
	if ($required == 1) {
		$required = " {validate:{required:true, messages:{required:'Lütfen bir görev giriniz'}}} ";
	}else{
		$required = "";
	}
	if ($aramali == 1) {
		$aramali = " selectaramali";
	}else{
		$aramali = "";
	}
	$bas = "<select name='dokumanlar' id='dokumanlar' class=\"big".$required."".$aramali."\"><option value=''>Seçiniz</option>";
	$db->query("select * from dokumanTalepleri order by DokumanTuru ASC, Dokumankodu ASC");
		while ($db->nextRecord()) {
			if (!empty($selected)) {
				if ($dt->Record["id"] == $selected) {
					$sec = "selected";
				}else{
					$sec = "";
				}
			}
			$bas .= "<option value='".$db->Record["id"]."'".$sec.">[".$db->Record["Dokumankodu"]."] - ".$db->Record["DokumanAdi"]."</option>";
		}
	$bas .= "</select>";
	return $bas;
}
Function Mailbul($username)
{

	$vq = mysql_query("select email from users where username = '".$username."'");
	$v = mysql_fetch_object($vq);
	 return $v->email;


}
Function Mailbul2($username)
{

	$vq = mysql_query("select email,adi,soyadi,gorev from users");
	

		while($v = mysql_fetch_array($vq))
		{
			$ad=$v["adi"];
			$soyad=$v["soyadiadi"];
			$gorev=$v["gorev"];

			if(strstr($username,$ad." ".$soyad))
				{
					$v2 = mysql_query("select adi from gorevler WHERE id='$gorev'");
						$wq=mysql_fetch_object($v2);
							if(strstr($username,$wq->adi))
								{
								return $v["email"];
								}
				}



		}
	 return $v->email;


}
function yoneticivesorumluyamail($metin,$ilgiliSurec)
{

}
function UOU_KararVeren($gid)
{
	$d=mysql_query("select * from iyilestirme_UOU_Grup where id='$gid'");
	$o=mysql_fetch_object($d);
	return $o->kararVeren;
}
Function SurecAdinaGonerMailGonder($DofNedeni,$DofTuru,$SurecAdi,$Uygunsuzluk)
{
	$vq = mysql_query("select id from surecler where adi = '".$SurecAdi."' AND bagli_surec='0'");
	$v = mysql_fetch_object($vq);
	$Surecid = $v->id;

	$vq2 = mysql_query("select sorumlu from surecler_sorumlular where surec_id = '".$Surecid."'");
	$v2 = mysql_fetch_object($vq2);
	$Surecid2 = $v2->adi;

	//$vq3 = mysql_query("select unvanid from gorevler where id = '".$Surecid2."'");
//	$v3 = mysql_fetch_object($vq3);
//	$Surecid3 = $v3->adi;

	$vq3 = mysql_query("select email,adi,soyadi from users where gorev = '".$Surecid2."'");

										while ($a = mysql_fetch_object($vq3)) 
										{
											MailGonder($a["email"],"Yeni Döfi Kaydı Oluşturuldu","Sayın ".$oku["adi"]." ".$oku["soyadi"]."<br><br>Yeni Bir Düzeltici ve Önleyici faaliyet isteği oluşturuldu.<br><br><table><tr><td>			
DÖFİ Türü : </td<td>>".$DofTuru."</td></tr><tr><td>			
DÖFİ Nedeni : </td<td>>".$DofNeden."</td></tr><tr><td>			
İlgili Süreç : </td<td>>".$ilgiliSurec."</td></tr><tr><td>			
Uygunsuzluk Tanımı : </td<td>>".$Uygunsuzluk."</td></tr>");	

										}



}
function MailGonder($to,$subject,$mesaj,$attachement=false) {
	try {
		$mail = new PHPMailer(true); //New instance, with exceptions enabled

		$body				= preg_replace('/\\\\/','', $mesaj); //Strip backslashes

		$mail->IsSMTP();                           // tell the class to use SMTP
		$mail->SMTPAuth   = true;                  // enable SMTP authentication
		$mail->Port       = 25;                    // set the SMTP server port
		$mail->Host       = MAIL_HOST; // SMTP server
		$mail->Username   = MAIL_FROM;     // SMTP server username
		$mail->Password   = MAIL_PASSWORD;            // SMTP server password

		$mail->IsSendmail();  // tell the class to use Sendmail

		$mail->From       = MAIL_FROM;
		$mail->FromName   = MAIL_FROM_NAME;
		$mail->AddAddress($to);
		$mail->Subject  = $subject;
		$mail->AltBody    = "Bu maili görüntülemek için HTML görüntüleyi kullanın"; // optional, comment out and test
		$mail->WordWrap   = 80; // set word wrap
		$mail->MsgHTML($body);
		$mail->IsHTML(true); // send as HTML

		if ($attachement) {
			$mail->AddAttachment($attachement);
		}

		$mail->Send();
	} catch (phpmailerException $e) {
		echo $e->errorMessage();
	}
}
function Yonlendir($adres,$saniye) {
	return '
	<script>window.top.location = \''.$adres.'\';</script>
	<meta http-equiv=\'refresh\' content=\''.$saniye.';URL='.$adres.'\' />
	';
}
function Yonlendir_Jquery($url,$time) {
	return '
	 <script type="text/javascript">
		var settimmer = 0;
		$(function(){
				window.setInterval(function() {
					var timeCounter = $("b[id=show-time]").html();
					var updateTime = eval(timeCounter)- eval(1);
					$("b[id=show-time]").html(updateTime);

					if(updateTime <= 0){
						$("#my-timer").hide();
						window.location = "'.$url.'";
					}
					
				}, 1000);

		});
	</script>
	<div id="my-timer"><b id="show-time">'.$time.'</b> saniye içerisinde otomatik olarak yönleneceksiniz.</div>
	';
}
function DokumanLogGir($islem,$mesaj) {
	$log = new Database;
	$log->query("INSERT INTO dokumanLogs VALUES ('', '$islem', '$mesaj')");
}

function DokumanlarLogGir($dokId,$Aciklama,$Tarih) {
	$log = new Database;
	$log->query("INSERT INTO dokumanlarLogs VALUES ('', '$dokId', '$Aciklama','$Tarih')");
}
function Son2RevizyonKoduAl($DokKodu) {
	$Sayi = substr($DokKodu,-2);
	return $Sayi;
}
function Son2RevizyonKoduSil($DokKodu) {
	//if (GetTableValue("value","ayarlar","where name = 'DokumanNumaralandirma'") == "otomatik") {
		$DokKodu = substr($DokKodu,0,-3);
	//}else{
	//	$DokKodu = $DokKodu;
	//}
	return $DokKodu;
}
function DokumanDownloadYetkiCheck($DokId) {
	global $GirisYapan, $session;
	$q = mysql_query("select * from dokumanlarYetkiDownload WHERE DokId = '$DokId' and (GorevId = '999999999' or GorevId = '".$GirisYapan["gorev"]."')");
	$t = mysql_num_rows($q);
	if ($session->userlevel == "9") {
		return "1";
	}else{
		return $t;
	}
}
function DokumanPrintYetkiCheck($DokId) {
	global $GirisYapan, $session;
	$q = mysql_query("select * from dokumanlarYetkiPrint WHERE DokId = '$DokId' and (GorevId = '999999999' or GorevId = '".$GirisYapan["gorev"]."')");
	$t = mysql_num_rows($q);
	if ($session->userlevel == "9") {
		return "1";
	}else{
		return $t;
	}
}

function CountDokumanInDokumanYapisi($dokYapiId) {
	$q = mysql_query("select * from dokumanlar where DokumanTuru = '$dokYapiId'");
	$t = mysql_num_rows($q);
	return $t;
}

function YururlugeGirenDokumanlarTopla() {
	global $GirisYapan;
	$q = mysql_query("select a.id, a.DokumanAdi, a.DokumanKodu, a.RevTarihi, a.YururlukTarihi from dokumanlar AS a INNER JOIN dokumanlarDagitim AS b ON a.id = b.DokId WHERE b.GorevId = '".$GirisYapan["gorev"]."' and b.Anasayfa = '1' and b.Okundu = '0' and a.YururlukTarihi <= '".time()."' and a.Active = '1' order by a.id DESC");
	$t = mysql_num_rows($q);
	return $t;
}
function tarihaycevir($t)
{


$ay=substr($t,3,2);
$yil=substr($t,-4);
$ay=AyAdi(intval($ay));

return $ay." ".$yil;


}
function tarihgecmismi($tarih,$id,$gid)
{
$trh = date("d.m.Y");
$gun = substr($trh,0,2);
$ay = substr($trh,3,2);
$yil = substr($trh,6,4);

$ggun= substr($tarih,0,2);

$gay= substr($tarih,3,2);

$gyear= substr($tarih,6,4);
//echo "<script type='text/javascript'> alert('".$ggun."-".$gay."-".$gyear."<br>".$gun."-".$ay."-".$yil."'); </script>";	
if($gyear<=$yil && $gay<=$ay && $ggun<=$gun)
{
	//echo "<script type='text/javascript'> alert('".$id."'); </script>";	
mysql_query("update iyilestirme_DofiSurec SET Durum='6' WHERE id='$id'");
mysql_query("update iyilestirme_DofiKayit SET Durum='6' WHERE id='$gid'");

return "1";
}



}

function tarihfarki($tarih1)
{

$tarih2 = date("Y-m-d"); 
					$baslangic     = strtotime($tarih2);
					$bitis         = strtotime($tarih1);
					$fark        = ($bitis-$baslangic)/86400;
					$toplantiSure= $fark;
					return $fark;
}
function iyilestirmedurumismi($durum)
{
$a= @mysql_fetch_object(mysql_query("select * from iyilestirme_DofiDurum where id=$durum"));
return $a->durum;
}
function IptaliTalepEdilenDokumanTopla($yt=false) {
	global $session, $GirisYapan;
	if ($yt){
		$where = "WHERE a.durum != '5' and b.DokumanAlan = '".$GirisYapan["alan"]."'";
	}else{
		$where = "WHERE a.TalepEden = '".$session->username."'";
	}
	$q = mysql_query("select a.id from dokumanIptalTalebi AS a INNER JOIN dokumanlar AS b ON a.DokId = b.id ".$where."");
	$t = mysql_num_rows($q);
	return $t;
}
function OnayBekleyenDokumanIptalTalebi() {
	global $session;
	$q = mysql_query("select * from dokumanIptalTalebi where Onaylayan = '".$session->username."' and Durum != '5' and IptalEdildi = '0'");
	$t = mysql_num_rows($q);
	return $t;
}
function GorusBekleyenDokumanIptalTalebi() {
	global $session;
	$q = mysql_query("select * from dokumanIptalTalebi where Gorus = '".$session->username."' and Durum = '3' and IptalEdildi = '0'");
	$t = mysql_num_rows($q);
	return $t;
}
function IptalEdilecekDokumanlariTopla() {
	global $session, $GirisYapan;
	//$q = mysql_query("select * from dokumanIptalTalebi WHERE IptalEdildi = '0' and IptalEdilenTarih != '0' and Durum = '5'");
	$iq = mysql_query("SELECT a.IptalEdilenTarih,a.DokId, c.DokumanAdi, c.DokumanKodu, c.RevTarihi, c.YururlukTarihi FROM dokumanIptalTalebi AS a INNER JOIN dokumanlarDagitim AS b ON b.DokId = a.DokId INNER JOIN dokumanlar AS c ON c.id = a.DokId WHERE a.Durum = '5' and (b.GorevId = '".$GirisYapan["gorev"]."' or b.GorevId = '999999999')");

	
$mm=(GetTableValue("value","ayarlar","where name = 'IptalEdilenDokumanYayindaKalmaSuresi'")*(60*60*24));
$w=0;
	while($i=mysql_fetch_object($iq)){
	$IptalTarihi = $i->IptalEdilenTarih+$mm;
	if($IptalTarihi>time())
		$w++;
	}
	
	
	return $w;
}
function ArtiEksi($div,$minusClass,$plusClass) {
	echo '<a href="javascript: void(0);" onclick="javacript: $(\'#'.$div.'\').toggle(); $(\'.'.$minusClass.'\').toggle(); $(\'.'.$plusClass.'\').toggle();" class="siyah"><img src="/gfx/plus.png" width="10" height="10" class="'.$plusClass.'"><img src="/gfx/minus.png" width="10" height="10" class="'.$minusClass.'" style="display:none;">';
}
/*
function YeniHazirlanmayiBekleyenRevizyonDokumanlari() {
	global $session;
	$q = mysql_query("select * from dokumanRevizyonTalebi WHERE (Durum = '3' or Durum = '8') and Hazirlayan = '$session->username'");
	$t = mysql_num_rows($q);
	return $t;
}
*/
/*
function YeniDokumanRevizyonTalebiTopla() {
	global $session,$GirisYapan;
	$q = mysql_query("select a.id from dokumanRevizyonTalebi AS a INNER JOIN dokumanlar AS b ON a.DokId = b.id WHERE (a.Durum = '0' or a.Durum = '4') and a.Yapildi = '0' and b.DokumanAlan = '".$GirisYapan["alan"]."'");
	$t = mysql_num_rows($q);
	return $t;
}
*/
function YeniDokumanRevizyonTalebiTopla() {
	global $session, $GirisYapan;
	$q = mysql_query("select * from dokumanRevizyonTalepleri WHERE (TalepDurumu != '4' and TalepDurumu != '2' and TalepDurumu != '20') and Alan = '".$GirisYapan["alan"]."' order by id DESC");
	$t = mysql_num_rows($q);
	return $t;
}
function YeniHazirlanmayiBekleyenRevizyonDokumanlari($u) {
	$q = mysql_query("select * from dokumanRevizyonHazirlama WHERE Hazirlayan = '$u' and Hazirlandi = '0' order by id DESC");
	$t = mysql_num_rows($q);
	return $t;
}
/*
function KontrolBekleyenRevizyonTalebiTopla() {
	global $session;
	$q = mysql_query("select * from dokumanRevizyonTalebi WHERE KontrolEden = '$session->username' and Yapildi = '0'");
	$t = mysql_num_rows($q);
	return $t;
}
*/
/*
function OnayBekleyenRevizyonTalebiTopla() {
	global $session;
	$q = mysql_query("select * from dokumanRevizyonTalebi WHERE (Durum = '5' or Durum = '6' or Durum = '9') and Onaylayan = '$session->username' and Yapildi = '0'");
	$t = mysql_num_rows($q);
	return $t;
}
*/
function KontrolBekleyenRevizyonTalebiTopla($u) {
	$i = 0;
	$q = mysql_query("select DokumanTalepId from dokumanRevizyonKontrol WHERE KontrolEden = '$u' and KontrolEdildi = '0' order by IstekTarih ASC");
	$t = mysql_num_rows($q);
	return $t;
}
function OnayBekleyenRevizyonTalebiTopla($u) {
	$i = 0;
	$q = mysql_query("select a.*, b.* from dokumanRevizyonOnay AS a INNER JOIN dokumanRevizyonTalepleri AS b ON a.DokumanTalepId = b.id WHERE a.Onaylayan = '$u' and a.Onaylandi = '0' and (b.TalepDurumu = '13' or b.TalepDurumu = '15' or b.TalepDurumu = '16' or b.TalepDurumu = '21' or b.TalepDurumu = '22') order by a.IstekTarih ASC");
	$t = mysql_num_rows($q);
	return $t;
}
function YeniDokumanTalebiTopla() {
	global $session, $GirisYapan;
	$q = mysql_query("select id from dokumanTalepleri WHERE (TalepDurumu != '4' and TalepDurumu != '2' and TalepDurumu != '20') and Alan = '$GirisYapan[alan]' order by id DESC");
	$t = mysql_num_rows($q);
	return $t;
}
function GorusunuzuBekleyenDokumanlarTopla() {
	global $session;
	$q = mysql_query("select id from dokumanGorusTalebi WHERE GorusAl = '$session->username' and GorusCevapId = '0' order by id DESC");
	$t = mysql_num_rows($q);
	return $t;
}
function GorusunuzuBekleyenRevizyonDokumanlarTopla() {
	global $session;
	$q = mysql_query("select id from dokumanRevizyonGorusTalebi WHERE GorusAl = '$session->username' and GorusCevapId = '0'");
	$t = mysql_num_rows($q);
	return $t;
}


function DokIdAlanBul($DokId) {
	$q = mysql_query("select DokumanAlan from dokumanlar where id = '$DokId'");
	$a = mysql_fetch_object($q);
	return $a->DokumanAlan;
}
function Kes($str,$start,$len) {
	return mb_substr($str, $start, $len, 'utf-8');
}

function SureceBagliDokumanSayisi($SurecId) {
	$q = mysql_query("select id from dokumanlar where Surec = '$SurecId'");
	$t = mysql_num_rows($q);
	return $t;
}
function ToplamUnvanaBagliKisi($UnvanId) {
	$q = mysql_query("select * from users where unvan = '$UnvanId'");
	$t = mysql_num_rows($q);
	return $t;
}
function ToplamGoreveBagliKisi($GorevId) {
	$q = mysql_query("select * from users where gorev = '$GorevId'");
	$t = mysql_num_rows($q);
	return $t;
}
function DokYapisinaBagliToplamDokumanSayisi($DokYapiId) {
	$q = mysql_query("select * from dokumanlar where DokumanTuru = '$DokYapiId'");
	$t = mysql_num_rows($q);
	return $t;
}
function HazirlamaniziBekleyenDokumanTalepleri($u) {
	$q = mysql_query("select * from dokumanHazirlama WHERE Hazirlayan = '$u' and Hazirlandi = '0' order by id DESC");
	$t = mysql_num_rows($q);
	return $t;
}
function KontrolunuzuBekleyenDokumanTalepleri($u) {
	$i = 0;
	$q = mysql_query("select DokumanTalepId from dokumanKontrol WHERE KontrolEden = '$u' and KontrolEdildi = '0' order by IstekTarih ASC");
	$t = mysql_num_rows($q);
	/*if ($t >= 1) {
		while ($k = mysql_fetch_object($q)) {
			$k_dok_id = $k->DokumanTalepId;
			$q1 = mysql_query("select * from dokumanHazirlama WHERE DokumanTalepId = '$k_dok_id' and Hazirlandi = '1'");
			$t1 = mysql_num_rows($q1);
			if ($t1 >= 1) {
				$i++;
			}
		}
	}*/
	return $t;
}
function OnayiniziBekleyenDokumanTalepleri($u) {
	$i = 0;
	$q = mysql_query("select a.*, b.* from dokumanOnay AS a INNER JOIN dokumanTalepleri AS b ON a.DokumanTalepId = b.id WHERE a.Onaylayan = '$u' and a.Onaylandi = '0' and (b.TalepDurumu = '13' or b.TalepDurumu = '15' or b.TalepDurumu = '16' or b.TalepDurumu = '21' or b.TalepDurumu = '22') order by a.IstekTarih ASC");
	$t = mysql_num_rows($q);
	/*if ($t >= 1) {
		while ($k = mysql_fetch_object($q)) {
			$k_dok_id = $k->DokumanTalepId;
			$q1 = mysql_query("select * from dokumanHazirlama WHERE DokumanTalepId = '$o_dok_id'");
			$t1 = mysql_num_rows($q1);
			$a1 = mysql_fetch_object($q1);
			$Hazirlandi = $a1->Hazirlandi;
			if ($t1 == 0 or $Hazirlandi == 1) {
				$i++;
			}
		}
	}*/
	return $t;
}
/*
function DokumanNoUret($Alan,$DokTuru,$Surec,$Revizyon="00") {
	$No = "";

	$AlanQ = mysql_query("SELECT * FROM Alan WHERE id = '$Alan'");
	$a = mysql_fetch_object($AlanQ);
	$AlanKodu = $a->Kodu;

	$DokTuruQ = mysql_query("SELECT * FROM dokumanyapisi WHERE id = '$DokTuru'");
	$b = mysql_fetch_object($DokTuruQ);
	$DokTuruKodu = $b->kod;

	$SurecQ = mysql_query("SELECT * FROM surecler WHERE id = '$Surec'");
	$c = mysql_fetch_object($SurecQ);
	$SurecKodu = $c->kodu;

	$SayiQ = mysql_query("SELECT Sayi FROM dokumanSayi WHERE Alan = '$Alan' and DokTuru = '$DokTuru' and Surec = '$Surec' order by id DESC LIMIT 1");
	$SayiT = mysql_num_rows($SayiQ);
	$d = mysql_fetch_object($SayiQ);
	if ($SayiT >= 1) {
		$SonSayi = $d->Sayi;
		$SonSayi = $SonSayi+1;
		$SonSayi = sprintf("%03d", $SonSayi);
	}else{
		$SonSayi = "001";
	}

	if (SISTEM_ALAN == "2") {
		$No .= $AlanKodu."-";
	}
	$No .= $DokTuruKodu."-";
	$No .= $SurecKodu."-";
	$No .= $SonSayi."-";
	$No .= $Revizyon;
	return $No;
}
*/

/* doküman kodu üretimi: */
function DokumanNoUret($Alan,$DokTuru,$Surec,$Revizyon="00") {
	$No = "";

	
	
	$AlanQ = mysql_query("SELECT * FROM Alan WHERE id = '$Alan'");
	$a = mysql_fetch_object($AlanQ);
	$AlanKodu = $a->Kodu;

	$DokTuruQ = mysql_query("SELECT * FROM dokumanyapisi WHERE id = '$DokTuru'");
	$b = mysql_fetch_object($DokTuruQ);
	$DokTuruKodu = $b->kod;

	$SurecQ = mysql_query("SELECT * FROM surecler WHERE id = '$Surec'");
	$c = mysql_fetch_object($SurecQ);
	$SurecKodu = $c->kodu;

	$ara=$DokTuruKodu."-".$SurecKodu;
	if($Alan!="0")
	$ara =$AlanKodu."-".$ara;
	$i=1;
	LogTut($ara);
	$d=mysql_query("select DokumanKodu FROM dokumanlar WHERE DokumanKodu LIKE '".$ara."%' ORDER BY DokumanKodu ASC");
	while($o=mysql_fetch_object($d))
	{
		$op=explode("-",$o->DokumanKodu);
		if($Alan=="2")
		{
		$x=3;
		}else
		$x=2;
		
		
		if(intval($op[$x])!=$i)
		{
		if($i<10)
		$ara=$ara."-00".$i."-00";
		else if($i>9 && $i<100)
		$ara=$ara."-0".$i."-00";
		else
		$ara=$ara."-".$i."-00";
		return $ara;
		}
		
		$i++;
		
	}
	if($i<10)
		$ara=$ara."-00".$i."-00";
		else if($i>9 && $i<100)
		$ara=$ara."-0".$i."-00";
		else
		$ara=$ara."-".$i."-00";
	return $ara;
	/*
	$SayiQ_SonSayiQ = mysql_query("SELECT Sayi FROM dokumanSayi WHERE Alan = '$Alan' and DokTuru = '$DokTuru' and Surec = '$Surec' order by Sayi DESC LIMIT 1");
	$SayiT_SonSayiQ = mysql_num_rows($SayiQ_SonSayiQ);
	$d2 = mysql_fetch_object($SayiQ_SonSayiQ);
	

	$sayilar = array();
	$sayi = 1;
	$SayiQ = mysql_query("SELECT Sayi FROM dokumanSayi WHERE Alan = '$Alan' and DokTuru = '$DokTuru' and Surec = '$Surec' order by Sayi ASC");
	$SayiT = mysql_num_rows($SayiQ);
		while ($d = mysql_fetch_object($SayiQ)) {
			$sayilar[$sayi] = $d->Sayi;
		$sayi++;
		}

		if ($SayiT_SonSayiQ > 0) {
			$SonSayi = intval($d2->Sayi);
			$SonSayi = $SonSayi+1;
			$ss=$SonSayi;
			$SonSayi = sprintf("%03d", $SonSayi);
		}else{
			$SonSayi = "001";
		}
	//}

	if (SISTEM_ALAN == "2") {
		$No .= $AlanKodu."-";
	}
	$No .= $DokTuruKodu."-";
	$No .= $SurecKodu."-";
	$No .= $SonSayi."-";
	$No .= $Revizyon;

	$No = str_replace("--","-",$No);

	return $No;*/

}
function SayiVer($SayiT,$sayilar) {
	$bas = "";
	for ($i=1;$i<=$SayiT;$i++) {
		if ($i == $sayilar[$i]) {
		}else{
			$bas = $i;
			break;
		}
	}
	return $bas;
}
/* :doküman kodu üretimi */

function ToplamGelenGorus($dokTalepId) {
	$q = mysql_query("select * from dokumanGorusTalebi where GorusCevapId != '0' and DokumanTalepId = '$dokTalepId'");
	$t = mysql_num_rows($q);
	return $t;
}
function ToplamGidenGorus($getId) {
	$q = mysql_query("select * from dokumanGorusTalebi WHERE DokumanTalepId = '$getId' and HangiAdim = '2'");
	$t = mysql_num_rows($q);
	return $t;
}
function ToplamGidenGorus2($getId) {
	$q = mysql_query("select * from dokumanGorusTalebi WHERE DokumanTalepId = '$getId' and HangiAdim = '2'");
	$t = mysql_num_rows($q);
	$yazi="";
	if($t==1)
	{
	while($oku=mysql_fetch_array($q))
	{
	$yazi=adsoyadgorevbul($oku["GorusAl"]);
	
	}
	}
	else if($t>1)
	while($oku=mysql_fetch_array($q))
	{
	$yazi=adsoyadgorevbul($oku["GorusAl"]).", ".$yazi;
	
	}
	if($t>0)
	return $t."( ".$yazi." )";
	else
	return $t;
}
function ToplamGelenGorusRevizyon($dokTalepId) {
	$q = mysql_query("select * from dokumanRevizyonGorusTalebi where GorusCevapId != '0' and DokumanTalepId = '$dokTalepId'");
	$t = mysql_num_rows($q);
	return $t;
}
function ToplamGidenGorusRevizyon($getId) {
	$q = mysql_query("select * from dokumanRevizyonGorusTalebi WHERE DokumanTalepId = '$getId' and HangiAdim = '2'");
	$t = mysql_num_rows($q);
	return $t;
}
function ToplamGidenGorusRevizyon2($getId) {
	$q = mysql_query("select * from dokumanRevizyonGorusTalebi WHERE DokumanTalepId = '$getId' and HangiAdim = '2'");
	$t = mysql_num_rows($q);
	$yazi="";
	if($t>0)
	while($oku=mysql_fetch_array($q))
	{
	$yazi=adsoyadgorevbul($oku["GorusAl"]).", ".$yazi;
	
	}
	if($t>0)
	return $t."( ".$yazi." )";
	else
	return $t;
}

function KayitlarSorumlularListele($kayitId,$ayrac="<br />") {
	$qq = mysql_query("select * from kayitlar_sorumlular where kayitId = '$kayitId'");
	while ($b = mysql_fetch_object($qq)) {
		$bas .= GorevAdiBul($b->sorumluId)."".$ayrac."";
	}
	return $bas;
}
function KayitlarSorumlularListele2($kayitId,$ayrac="<br />") {
	$qq = mysql_query("select * from kayitlar_sorumlular2 where kayitId = '$kayitId'");
	while ($b = mysql_fetch_object($qq)) {
		$bas .= GorevAdiBul($b->sorumluId)."".$ayrac."";
	}
	return $bas;
}

function DahaOnceKayitYapilmisMi($dokumanId) {
	$q = mysql_query("select id from kayitlar where dokumanid = '$dokumanId'");
	$t = mysql_num_rows($q);
	return $t;
}
function DokDosyaBul($dokumanId) {
	$q = mysql_query("select Dosya from dokumanlar where id = '$dokumanId'");
	$ok=mysql_fetch_array($q);
	return $ok["Dosya"];
}


function YeniDokTalebiDurum($TalepDurumu) {
	if ($TalepDurumu == "3") {
		$TalepDurumuText = "Görüşte";
	}elseif ($TalepDurumu == "2") {
		$TalepDurumuText = "Reddedildi";
	}elseif ($TalepDurumu == "1") {
		$TalepDurumuText = "Onaylandı";
	}elseif ($TalepDurumu == "0") {
		$TalepDurumuText = "Yeni talep";
	}elseif ($TalepDurumu == "4") {
		$TalepDurumuText = "Talep iptal";
	}elseif ($TalepDurumu == "5") {
		$TalepDurumuText = "Görüşten geldi";
	}elseif ($TalepDurumu == "6" || $TalepDurumu == "1") {
		$TalepDurumuText = "Taslak";
	}elseif ($TalepDurumu == "8") {
		$TalepDurumuText = "Görüşte";
	}elseif ($TalepDurumu == "7") {
		$TalepDurumuText = "Görüşte";
	}elseif ($TalepDurumu == "9") {
		$TalepDurumuText = "Hazırlayanda";
	}elseif ($TalepDurumu == "10") {
		$TalepDurumuText = "Hazırlayandan Geldi";
	}elseif ($TalepDurumu == "13") {
		$TalepDurumuText = "Onaylayanda";
	}elseif ($TalepDurumu == "18") {
		$TalepDurumuText = "Onaylayan Değişiklik";
	}elseif ($TalepDurumu == "17") {
		$TalepDurumuText = "Onaylayan Red";
	}elseif ($TalepDurumu == "19") {
		$TalepDurumuText = "Son şekli veriliyor";
	}elseif ($TalepDurumu == "16") {
		$TalepDurumuText = "Onaylayan görüşe gönderdi";
	}elseif ($TalepDurumu == "15") {
		$TalepDurumuText = "Onaylayan görüşünden geldi";
	}elseif ($TalepDurumu == "21") {
		$TalepDurumuText = "Onaylayan kontrolünde";
	}elseif ($TalepDurumu == "22") {
		$TalepDurumuText = "Onaylayan kontrolünden geldi";
	}elseif ($TalepDurumu == "20") {
		$TalepDurumuText = "Yürürlüğe girdi";
	}else{
		$TalepDurumuText = "?";
	}
	return $TalepDurumuText;
}

function IptalTalebiDurumText($IptalDurum) {
	if ($IptalDurum == "0") {
		$IptalDurum = "Bekliyor";
	}elseif ($IptalDurum == "1") {
		$IptalDurum = "Onayda";
	}elseif ($IptalDurum == "2") {
		$IptalDurum = "Talep Red";
	}elseif ($IptalDurum == "3") {
		$IptalDurum = "Görüşte";
	}elseif ($IptalDurum == "4") {
		$IptalDurum = "Onaylayan Red";
	}elseif ($IptalDurum == "5") {
		$IptalDurum = "İptal Edildi";
	}
	return $IptalDurum;
}



function AyAdi($i) {
	if ($i == "1") {
		return "Ocak";
	}elseif ($i == "2") {
		return "Şubat";
	}elseif ($i == "3") {
		return "Mart";
	}elseif ($i == "4") {
		return "Nisan";
	}elseif ($i == "5") {
		return "Mayıs";
	}elseif ($i == "6") {
		return "Haziran";
	}elseif ($i == "7") {
		return "Temmuz";
	}elseif ($i == "8") {
		return "Ağustos";
	}elseif ($i == "9") {
		return "Eylül";
	}elseif ($i == "10") {
		return "Ekim";
	}elseif ($i == "11") {
		return "Kasım";
	} elseif ($i == "12") {
		return "Aralık";
	} 
}

function Surec_HedefVeriBul($HedefId, $Parca) {
	return GetTableValue("Veri", "performansGostergeleri_veriler", "WHERE HedefId = '$HedefId' and Parca = '$Parca'");
}
function Surec_HedefVeriBul2($HedefId, $Parca, $time) {
	return GetTableValue("Veri", "_performansGostergeleri_veriler", "WHERE Kayit_Tarihi='$time' AND HedefId = '$HedefId' AND Parca = '$Parca'");
}

function PerformansGostergesiSorumlular($id) {
	$sorumlular = "";
	$q = mysql_query("select Sorumlu from performansGostergeleri_sorumlular WHERE GostergeId = '$id'");
		while ($a = mysql_fetch_object($q)) {
			$sorumlular .= UsernameGorev($a->Sorumlu)."<br />";
		}
	return $sorumlular;
}
function PerformansGostergesiSorumlular3($id) {
	
	$q = mysql_query("select Sorumlu from performansGostergeleri_sorumlular WHERE GostergeId = '$id'");
		while ($a = mysql_fetch_object($q)) {
			$sorumlular = $a->Sorumlu;
		}
	return $sorumlular;
}
function PerformansGostergesiSorumlular2($id) {
	$sorumlular = "";
	$q = mysql_query("select Sorumlu from performansGostergeleri_sorumlular WHERE GostergeId = '$id'");
		while ($a = mysql_fetch_object($q)) {
				if($a->Sorumlu!="")
			{
					$asdp=adsoyadgorevbul($a->Sorumlu);
					if(strstr($sorumlular,$asdp))
					{
					
					}else
					{
					$sorumlular = $asdp;	
					}
			
			}
		}
	return $sorumlular;
}
function HedefinYiliniBul($id)
{
	$db=mysql_query("select Baslangic_Yil FROM performansGostergeleri_hedefler WHERE id='$id'");
	$o=mysql_fetch_array($db);
	return $o["Baslangic_Yil"];
}
function PerformansGostergesiSorumlusuMu($GostergeId, $User) {
	$q = mysql_query("select Sorumlu from performansGostergeleri_sorumlular WHERE GostergeId = '$GostergeId' and Sorumlu = '$User'");
	$t = mysql_num_rows($q);
	return $t;
}
function PerformansGostergesiGrafikIzniVarMi($GostergeId, $User) {
	$q = mysql_query("select Sorumlu from performansGostergeleri_grafikizni WHERE GostergeId = '$GostergeId' and Sorumlu = '$User'");
	$t = mysql_num_rows($q);
	return $t;
}


function SurecSorumlular($SurecId) {
	$liste = "";
	$q = mysql_query("select sorumlu from surecler_sorumlular WHERE surec_id = '$SurecId'");
		while ($a = mysql_fetch_object($q)) {
			$liste .= GorevAdiBul($a->sorumlu).", ";
		}
	$liste = substr($liste,0,-2);
	return $liste;
}
function SurecSorumlularOnay($SurecId) {
	$liste = "";
	$q = mysql_query("select sorumlu from surecler_sorumlular_onay WHERE surec_id = '$SurecId'");
		while ($a = mysql_fetch_object($q)) {
			$liste .= GorevAdiBul($a->sorumlu).", ";
		}
	$liste = substr($liste,0,-2);
	return $liste;
}function SurecSorumlularRevize($SurecId) {
	$liste = "";
	$q = mysql_query("select sorumlu from surecler_sorumlular_Revize WHERE surec_id = '$SurecId'");
		while ($a = mysql_fetch_object($q)) {
			$liste .= GorevAdiBul($a->sorumlu).", ";
		}
	$liste = substr($liste,0,-2);
	return $liste;
}

function SurecKaynaklar($SurecId) {
	$liste = "";
	$q = mysql_query("select kaynaklar from surecler_kaynaklar WHERE surecId = '$SurecId' order by Sira ASC, id ASC");
		while ($a = mysql_fetch_object($q)) {
			$liste .= $a->kaynaklar.", ";
		}
	$liste = substr($liste,0,-2);
	return $liste;
}
function SurecKaynaklarOnay($SurecId) {
	$liste = "";
	$q = mysql_query("select kaynaklar from surecler_kaynaklar_onay WHERE surecId = '$SurecId' order by Sira ASC, id ASC");
		while ($a = mysql_fetch_object($q)) {
			$liste .= $a->kaynaklar.", ";
		}
	$liste = substr($liste,0,-2);
	return $liste;
}
function SurecKaynaklarRevize($SurecId) {
	$liste = "";
	$q = mysql_query("select kaynaklar from surecler_kaynaklar_Revize WHERE surecId = '$SurecId' order by Sira ASC, id ASC");
		while ($a = mysql_fetch_object($q)) {
			$liste .= $a->kaynaklar.", ";
		}
	$liste = substr($liste,0,-2);
	return $liste;
}
function SurecCiktilar($SurecId) {
	$liste = "";
	$q = mysql_query("select cikti from surecler_cikti WHERE surecId = '$SurecId' order by Sira ASC, id ASC");
		while ($a = mysql_fetch_object($q)) {
			$liste .= $a->cikti."<br />";
		}
	//$liste = substr($liste,0,-2);
	return $liste;
}
function SurecCiktilarOnay($SurecId) {
	$liste = "";
	$q = mysql_query("select cikti from surecler_cikti_onay WHERE surecId = '$SurecId' order by Sira ASC, id ASC");
		while ($a = mysql_fetch_object($q)) {
			$liste .= $a->cikti."<br />";
		}
	//$liste = substr($liste,0,-2);
	return $liste;
}function SurecCiktilarRevize($SurecId) {
	$liste = "";
	$q = mysql_query("select cikti from surecler_cikti_Revize WHERE surecId = '$SurecId' order by Sira ASC, id ASC");
		while ($a = mysql_fetch_object($q)) {
			$liste .= $a->cikti."<br />";
		}
	//$liste = substr($liste,0,-2);
	return $liste;
}
function SurecGirdiler($SurecId) {
	$liste = "";
	$q = mysql_query("select girdi from surecler_girdi WHERE surecId = '$SurecId' order by Sira ASC, id ASC");
		while ($a = mysql_fetch_object($q)) {
			$liste .= $a->girdi."<br />";
		}
	//$liste = substr($liste,0,-2);
	return $liste;
}
function SurecGirdilerOnay($SurecId) {
	$liste = "";
	$q = mysql_query("select girdi from surecler_girdi_onay WHERE surecId = '$SurecId' order by Sira ASC, id ASC");
		while ($a = mysql_fetch_object($q)) {
			$liste .= $a->girdi."<br />";
		}
	//$liste = substr($liste,0,-2);
	return $liste;
}
function SurecGirdilerRevize($SurecId) {
	$liste = "";
	$q = mysql_query("select girdi from surecler_girdi_Revize WHERE surecId = '$SurecId' order by Sira ASC, id ASC");
		while ($a = mysql_fetch_object($q)) {
			$liste .= $a->girdi."<br />";
		}
	//$liste = substr($liste,0,-2);
	return $liste;
}
function SurecFaaliyetler($SurecId) {
	$liste = "";
	$say = 1;
	$q = mysql_query("select faaliyetler from surecler_faaliyetler WHERE surecId = '$SurecId' order by Sira ASC, id ASC");
	$t = mysql_num_rows($q);
		$liste .= "<div style='float: left; padding: 5px;'>";

		while ($a = mysql_fetch_object($q)) {
			$liste .= $a->faaliyetler."<br />";
			if ($say == 60) {
				$liste .= "</div><div style='float: left; padding: 5px'>";
			}
		$say++;
		}
		$liste .= "</div>";
	return $liste;
}
function SurecFaaliyetlerOnay($SurecId) {
	$liste = "";
	$say = 1;
	$q = mysql_query("select faaliyetler from surecler_faaliyetler_Revize WHERE surecId = '$SurecId' order by Sira ASC, id ASC");
	$q2 = mysql_query("select faaliyetler from surecler_faaliyetler_onay WHERE surecId = '$SurecId' order by Sira ASC, id ASC");
	$t = mysql_num_rows($q);
	
	if($t>0){
	$liste .= "<div style='float: left; padding: 5px;'>";

		while ($a = mysql_fetch_object($q)) {
			$liste .= $a->faaliyetler."<br />";
			if ($say == 60) {
				$liste .= "</div><div style='float: left; padding: 5px'>";
			}
		$say++;
		}
		$liste .= "</div>";
	}else if(mysql_num_rows($q2)>0)
	{
	$liste .= "<div style='float: left; padding: 5px;'>";

		while ($a = mysql_fetch_object($q2)) {
			$liste .= $a->faaliyetler."<br />";
			if ($say == 60) {
				$liste .= "</div><div style='float: left; padding: 5px'>";
			}
		$say++;
		}
		$liste .= "</div>";
	}
		
	return $liste;
}
function SurecFaaliyetler_PDF($SurecId) {
	$q = mysql_query("select faaliyetler from surecler_faaliyetler WHERE surecId = '$SurecId' order by Sira ASC, id ASC");
	$t = mysql_num_rows($q);
		while ($a = mysql_fetch_object($q)) {
			$faaliyetler = $a->faaliyetler;
			$faaliyetler = str_replace("<b>", "<br /><b>", $faaliyetler);
			$faaliyetler = str_replace("</b>", "</b><br />", $faaliyetler);

			if (strpos($faaliyetler, "</b><br />") === false) {
				$liste .= $faaliyetler.", ";
			}else{
				$liste .= $faaliyetler;
			}
		}
	return $liste;
}
function SurecGostergeler($SurecId) {
	$liste = "";
	$q = mysql_query("select Adi from performansGostergeleri WHERE Surec = '$SurecId' order by id ASC");
		while ($a = mysql_fetch_object($q)) {
			$liste .= $a->Adi."<br />";
		}
	return $liste;
}
function PGSurecbul($id) {
	
	$q = mysql_query("select Surec from performansGostergeleri WHERE id = '$id'");
		while ($a = mysql_fetch_object($q)) {
			$liste = $a->Surec;
		}
	return $liste;
}
function SurecDokümanlar($SurecId) {
	$liste = "";

	$q = mysql_query("select id, turu from dokumanyapisi ORDER BY sira ASC");
		while ($a = mysql_fetch_object($q)) {	
			$q2 = mysql_query("select id, DokumanAdi, DokumanKodu from dokumanlar WHERE Surec = '$SurecId' and DokumanTuru = '".$a->id."' order by DokumanKodu");
			$t2 = mysql_num_rows($q2);
			if ($t2 >= 1) {
				$liste .= "<div style='clear: both;'></div><b>".$a->turu."</b><div style='clear: both;'></div>";
				$say = 0;
				while ($b = mysql_fetch_object($q2)) {
					if ($t2 <= 30) {
						$dokumanadi = $b->DokumanAdi;
					}else{
						$dokumanadi = Son2RevizyonKoduSil($b->DokumanKodu);
					}
					$liste .= "<a href='/dokumanGoruntule.php?".URL::encode("?dokId=".$b->id."")."' style='color: black;' target='_blank'>".$dokumanadi."</a>, ";
				$say++;
				}
			}
		}
	$liste = substr($liste,0,-2);
	return $liste;
}
function Periyodubul($id){
$q=mysql_query("select IzlemePeriyodu from performansGostergeleri where	id='$id'");
$o=mysql_fetch_array($q);

return $o["IzlemePeriyodu"];

}
function SurecParcaAyListesi($GostergeVeriGirisPeriyodu,$Baslangic_Ay) {
	$AyListesi = array();
				
	$HP = "12"; // hedefin periyodu her zaman 1 yıl yani 12 ay. 
	$PP = $GostergeVeriGirisPeriyodu; // performans göstergesi periyodu
	$KP = $HP / $PP; // Kaç parça var
	$HB = $Baslangic_Ay;



	// Ocak-Aralık arasında ortalardan bir tarihten başladıysa geriye dönük parça adedini $KP den çıkarmamız gerek
	if ($GostergeVeriGirisPeriyodu == "1") {
		$KP = $KP-$Baslangic_Ay+1;
	}else{
		if ($Baslangic_Ay > $GostergeVeriGirisPeriyodu) {
			$ParcadanCikar = floor($Baslangic_Ay/$GostergeVeriGirisPeriyodu);
			$KP = $KP-$ParcadanCikar;
		}
	}


	for ($ii=1;$ii<=$KP;$ii++) { // ii = dış döngü
		$aylar = "";
		for ($i=0;$i<$PP-($PP-1);$i++) { // iç döngü
			
			if ($ii == 1) { // ii = 1 ise formül:   (HB + i) * ii
				$sonuc = (($HB + $i) * $ii);
			}elseif ($ii >= 2) {  // ii >= 2 ise formül:   HB + i + (PP*(ii - 1))
				$sonuc = ( ($HB + $i) + ($PP*($ii-1)) );			
			}
			
		}// iç bitii
		for ($x=0;$x<$PP;$x++) { // performans göstergesi periyodu kadar yan yana ayları bas
			$HangiAy = $sonuc+$x;
			/*if ($HangiAy > "12") { // 12.aydan büyükse yılı 1 arttır ve ayı bul
				$HangiAy = $HangiAy-12;
			}*/
			$aylar .= AyAdi($HangiAy)." - ";
		}

		// sondaki - al
		$aylar = substr($aylar,0,-2);
		$AyListesi[] = $aylar;
		//$AyListesi[$ii] = $aylar;
	} // dış bitiş

	return $AyListesi;
}


function SurecHedefeVeriGirilmisMi($HedefId,$Ay) {
	$q = mysql_query("select id from performansGostergeleri_veriler WHERE HedefId = '$HedefId' and ParcaAciklama = '$Ay'");
	$t = mysql_num_rows($q);
	if ($t >= 1) {
		return "disabled";
	}else{
		return "";
	}
}

function AyAdiniSayiyaCevir($ay) {
	if ($ay == "Ocak") {
		return "1";
	}elseif ($ay == "Şubat") {
		return "2";
	}elseif ($ay == "Mart") {
		return "3";
	}elseif ($ay == "Nisan") {
		return "4";
	}elseif ($ay == "Mayıs") {
		return "5";
	}elseif ($ay == "Haziran") {
		return "6";
	}elseif ($ay == "Temmuz") {
		return "7";
	}elseif ($ay == "Ağustos") {
		return "8";
	}elseif ($ay == "Eylül") {
		return "9";
	}elseif ($ay == "Ekim") {
		return "10";
	}elseif ($ay == "Kasım") {
		return "11";
	}elseif ($ay == "Aralık") {
		return "12";
	}
}
function GecerliAydaysakAktifEt($ay,$yil) {
	if ($yil < date("Y")) {
		$sonuc = " disabled";
	}elseif ($yil == date("Y")) {
		$aylar = explode("-",$ay);
		$ensondakiay = end($aylar);
		if (AyAdiniSayiyaCevir($ensondakiay) == date("n")) { // eldeki ay bu aya eşitse
			$sonuc = "";
		}elseif (AyAdiniSayiyaCevir($ensondakiay) == date("n")-1) { // bir önceki ayı da aç
			if (date("n") == 1) { // Ocak ayında aralık ayını aktif etmesin diye
				$sonuc = "disabled";
			}else{
				$sonuc = "";
			}
		}else{
			$sonuc = " disabled";
		}
	}
	return $sonuc;
}

function GecerliAydaysakAktifEt_VeriKontrolu_Cron($ay,$yil) {
	if ($yil < date("Y")) {
		$sonuc = " disabled";
	}else{
		$aylar = explode("-",$ay);
		$ensondakiay = end($aylar);
		if (AyAdiniSayiyaCevir($ensondakiay) == date("n")-1) { // eldeki ay bu aya eşitse
			$sonuc = "";
		}else{
			$sonuc = " disabled";
		}
	}
	return $sonuc;
}


class Uyarilar {
	
	function Basarili($str) {
		return '
		<div class="message green">
				<span>'.$str.'</span>
		</div>

		';
	}
	function Hata($str) {
		return '
		<div class="message red">
			<span>'.$str.'</span>
		</div>
		';
	}
	function Uyari($str) {
		return '
		<div class="message orange">
			<span>'.$str.'</span>
		</div>
		';
	}
	function Bilgi($str) {
		return '
		<div class="message blue">
			<span>'.$str.'</span>
		</div>
		';
	}
}

class CssUyari {
	
	function Basarili($str) {
		return '<div class="tamam">'.$str.'</div>';
	}
	function Hata($str) {
		return '<div class="hata">'.$str.'</div>';
	}
	function Uyari($str) {
		return '<div class="ikaz">'.$str.'</div>';
	}
	function Bilgi($str) {
		return '<div class="bilgi">'.$str.'</div>';
	}
}
/**
 * URL şifreleme & güvenlik sınıfı
 * https://github.com/DouglasMedeiros/Encrypt-URL-for-PHP
 * URL::encode("?islem=1&id=2"); mutlaka ? işareti ile başlamalı
**/
class URL {
        private static $key = SECRET;
        private static $size = 16;
        

        static function encode($string)
        {
                $string = gzcompress($string) . "\x13";
                $n = strlen($string);

                if($n % 16)
                {
                        $string .= str_repeat("\0", 16 - ($n % 16));
                }
                
                $i = 0;
                $enc_text = self::randomize();
                $iv = substr(self::$key ^ $enc_text, 0, 512);
                
                while ($i < $n)
                {
                        $block = substr($string, $i, 16) ^ pack('H*', md5($iv));
                        $enc_text .= $block;
                        $iv = substr($block . $iv, 0, 512) ^ self::$key;
                        $i += 16;
                }
                
                return urlencode(base64_encode(base64_encode($enc_text)));
        }
        
        static function decode()
        {
                $string = $_SERVER['QUERY_STRING'];
                
                if(strlen($string) > 0)
                {
                        $string = base64_decode(base64_decode($string));
                        $n = strlen($string);
                        $i = self::$size;
                        $plain_text = '';
                        $iv = substr(self::$key ^ substr($string, 0, self::$size), 0, 512);
                        
                        while ($i < $n)
                        {
                                $block = substr($string, $i, 16);
                                $plain_text .= $block ^ pack('H*', md5($iv));
                                $iv = substr($block . $iv, 0, 512) ^ self::$key;
                                $i += 16;
                        }
                        
                        $plain_text = @gzuncompress( preg_replace( '/\\x13\\x00*$/' , '' , $plain_text ) );
                        
                        if( !$plain_text )
                        {
                                exit("URL sifrelenmeden bu sayfalar goruntulenemez");
                        }

                        $url = parse_url(urldecode( $plain_text ) );
                        $parametros = explode("&", $url['query']);
                        
                        for($i = 0; $i < count($parametros); $i++)
                        {
                                $valor = explode("=", trim( urldecode( strip_tags( $parametros[$i] ) ) ) );
                                $_REQUEST[ $valor[0] ] = $valor[1];
                        }
                        
                        unset( $_REQUEST[ urldecode($_SERVER['QUERY_STRING']) ] );
                }
        }
        
        private static function randomize()
        {
                $iv = '';
                $i = 0;
                while($i < self::$size)
                {
                        $iv .= chr(mt_rand() & 0xff);
                        $i++;
                }
                return $iv;
        }
}

$uyari = new Uyarilar();
$uyariCss = new CssUyari();







function GetTableValue($column,$table,$where) {
	$q = mysql_query("SELECT $column FROM $table $where");
	$a = mysql_fetch_object($q);
	return $a->$column;
}
function EscapeData($data) { 
	global $database;
	if (ini_get('magic_quotes_gpc')) {
		$data = stripslashes($data);
	}
	return mysql_real_escape_string (trim ($data), $database->connection);
}

function sikayetfaliyettevarmi($id,$kullanici)
{
	$d=mysql_query("select * from sikayetFaliyetler where sid='$id' AND sorumlu='$kullanici' AND durum!='3'");
		return mysql_num_rows($d); 
}
function UOU_Durum($i)
{

	if($i=="1")
	return "Beklemede";
	else if($i=="2")
	return "İşlem Başlatıldı";
	else if($i=="3")
	return "Kapatıldı";
	else if($i=="4")
	return "Değişiklik Talebi";
	else if($i=="7")
	return "İşlem Tamamlandı";
	else 
	return "";
}function tirnak_replace ($par)
{
	return str_replace(
		array(
			"'", "\""
			),
		array(
			"&#39;", "&quot;"
		),
		$par
	);
}
?>